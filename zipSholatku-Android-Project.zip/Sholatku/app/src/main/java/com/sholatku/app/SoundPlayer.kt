package com.sholatku.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.PowerManager
import java.io.File

class SoundPlayer(private val c: Context) {
    private var mp: MediaPlayer? = null
    private var savedVol = -1
    private val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun newPlayer(): MediaPlayer {
        val m = MediaPlayer()
        m.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
        return m
    }

    private fun build(pick: String, rawId: Int): MediaPlayer {
        if (pick.isNotEmpty() && Regex("[A-Za-z0-9_-]+").matches(pick)) {
            val f = File(File(c.filesDir, "audio"), pick)
            if (f.exists()) {
                val m = newPlayer()
                try {
                    m.setDataSource(f.absolutePath)
                    return m
                } catch (e: Exception) {
                    m.release()
                }
            }
        }
        val m = newPlayer()
        val afd = c.resources.openRawResourceFd(rawId)
        m.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
        afd.close()
        return m
    }

    /** kind: "azan" | "iq" | "ht" */
    fun play(kind: String, pick: String, vol: Float, full: Boolean, loop: Boolean, onDone: (() -> Unit)?) {
        stop()
        try {
            if (full) {
                savedVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            }
            val rawId = when (kind) {
                "azan" -> R.raw.azan
                "iq" -> R.raw.iqomah
                else -> R.raw.hati
            }
            val v = if (full) 1f else vol.coerceIn(0f, 1f)
            val m = build(pick, rawId)
            m.isLooping = loop
            m.setVolume(v, v)
            m.setOnPreparedListener { it.start() }
            m.setOnCompletionListener {
                if (mp === it) {
                    stop()
                    onDone?.invoke()
                }
            }
            m.setOnErrorListener { p, _, _ ->
                if (mp === p) {
                    stop()
                    onDone?.invoke()
                }
                true
            }
            mp = m
            m.prepareAsync()
        } catch (e: Exception) {
            stop()
            onDone?.invoke()
        }
    }

    fun stop() {
        mp?.let {
            try { it.stop() } catch (e: Exception) { }
            try { it.release() } catch (e: Exception) { }
        }
        mp = null
        if (savedVol >= 0) {
            try { am.setStreamVolume(AudioManager.STREAM_ALARM, savedVol, 0) } catch (e: Exception) { }
            savedVol = -1
        }
    }
}
